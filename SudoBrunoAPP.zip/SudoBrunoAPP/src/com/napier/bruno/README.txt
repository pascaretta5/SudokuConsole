####################BRUNO SUDOKU GAME APP######################
##COMPILE:
1. Very simple! Inside the main class, that will be a method called "public static void main(String[] args) { game(); }" with a green arrow at the left (if you use IntelliJ Idea).
2. Then, just compile it.
##AFTER COMPILE:

----- Have fun! -----